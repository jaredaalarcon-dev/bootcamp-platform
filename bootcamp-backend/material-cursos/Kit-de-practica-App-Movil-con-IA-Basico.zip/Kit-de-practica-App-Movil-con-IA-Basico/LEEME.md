# Kit de práctica · Apps móviles con IA (Básico)

Código de los ejercicios del curso en **Flutter**. Copia la carpeta `lib/` dentro de un proyecto nuevo.

## Pasos
```bash
flutter create mi_app
cd mi_app
# Copia la carpeta lib/ de este kit encima de la del proyecto
flutter pub add http shared_preferences firebase_core firebase_ai
flutter run
```

## Contenido
| Archivo | Ejercicio |
|---|---|
| lib/main.dart | Punto de entrada, tema con los colores SIJB |
| lib/screens/inicio_screen.dart | Menú de ejercicios |
| lib/screens/tarjeta_screen.dart | 1 · Tarjeta de presentación (widgets y layouts) |
| lib/screens/tareas_screen.dart | 2 · Lista de tareas guardada (shared_preferences) |
| lib/screens/clima_screen.dart | 3 · Consumo de API (http + FutureBuilder) |
| lib/screens/asistente_screen.dart | 4 · Asistente con IA (Gemini vía Firebase AI Logic) |

## Activar el asistente con IA (ejercicio 4)
1. Crea un proyecto en https://console.firebase.google.com y activa **AI Logic** (API de Gemini para desarrolladores).
2. Instala la herramienta: `dart pub global activate flutterfire_cli`
3. En tu proyecto ejecuta `flutterfire configure` y elige tu proyecto de Firebase.
4. Vuelve a ejecutar la app. Sin este paso, los ejercicios 1 a 3 funcionan igual y el 4 te muestra cómo activarlo.

> 🔐 Con Firebase AI Logic **no** pones ninguna clave de API dentro de la app.
> 📶 En Android, para la versión final agrega el permiso de internet en
> `android/app/src/main/AndroidManifest.xml`: `<uses-permission android:name="android.permission.INTERNET"/>`

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
