# Retos extra · Básico

1. **Tema oscuro**: agrega un interruptor en el inicio para cambiar entre tema claro y oscuro.
2. **Tareas con fecha**: añade una fecha límite a cada tarea con `showDatePicker`.
3. **Otra ciudad**: en el clima, permite elegir entre Lima, Arequipa y Cusco (cambia latitud y longitud).
4. **Asistente con personalidad**: cambia la instrucción del sistema para que sea un tutor de matemáticas.
5. **APK**: genera tu instalador con `flutter build apk --release` e instálalo en tu celular.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
