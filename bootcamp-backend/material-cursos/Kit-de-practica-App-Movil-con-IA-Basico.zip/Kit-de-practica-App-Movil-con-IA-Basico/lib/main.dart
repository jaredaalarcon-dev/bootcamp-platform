import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'screens/inicio_screen.dart';

/// true cuando Firebase está configurado (ejercicio 4: asistente con IA)
bool firebaseListo = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    // Usa la configuración que crea "flutterfire configure"
    await Firebase.initializeApp();
    firebaseListo = true;
  } catch (_) {
    firebaseListo = false; // Los ejercicios 1 a 3 no necesitan Firebase
  }
  runApp(const KitApp());
}

class KitApp extends StatelessWidget {
  const KitApp({super.key});

  static const cian = Color(0xFF00C0E7);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kit SIJB · App móvil con IA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: cian, useMaterial3: true),
      darkTheme: ThemeData(colorSchemeSeed: cian, brightness: Brightness.dark, useMaterial3: true),
      home: const InicioScreen(),
    );
  }
}
