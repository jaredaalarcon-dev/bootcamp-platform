import 'package:firebase_ai/firebase_ai.dart';
import 'package:flutter/material.dart';

import '../main.dart';

// Ejercicio 4: chat con IA usando Gemini a través de Firebase AI Logic.
// La clave de la IA NO va en la app: Firebase se encarga de forma segura.
class AsistenteScreen extends StatefulWidget {
  const AsistenteScreen({super.key});

  @override
  State<AsistenteScreen> createState() => _AsistenteScreenState();
}

class _Mensaje {
  _Mensaje(this.texto, {required this.esUsuario});
  final String texto;
  final bool esUsuario;
}

class _AsistenteScreenState extends State<AsistenteScreen> {
  final _texto = TextEditingController();
  final _mensajes = <_Mensaje>[];
  ChatSession? _chat;
  bool _pensando = false;

  @override
  void initState() {
    super.initState();
    if (firebaseListo) {
      final modelo = FirebaseAI.googleAI().generativeModel(
        model: 'gemini-2.5-flash', // usa el modelo vigente que indique la documentación
        systemInstruction: Content.system(
          'Eres un asistente de estudio amable. Responde en español, en pocas líneas y con ejemplos sencillos.',
        ),
      );
      _chat = modelo.startChat(); // el chat recuerda los mensajes anteriores
    }
  }

  Future<void> _enviar() async {
    final texto = _texto.text.trim();
    if (texto.isEmpty || _chat == null || _pensando) return;
    setState(() {
      _mensajes.add(_Mensaje(texto, esUsuario: true));
      _pensando = true;
    });
    _texto.clear();
    try {
      final respuesta = await _chat!.sendMessage(Content.text(texto));
      setState(() => _mensajes.add(_Mensaje(respuesta.text ?? '…', esUsuario: false)));
    } catch (e) {
      setState(() => _mensajes.add(_Mensaje('No pude responder ahora. Intenta de nuevo.', esUsuario: false)));
    } finally {
      setState(() => _pensando = false);
    }
  }

  @override
  void dispose() {
    _texto.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    if (!firebaseListo) {
      return Scaffold(
        appBar: AppBar(title: const Text('Asistente con IA')),
        body: const Padding(
          padding: EdgeInsets.all(24),
          child: Text('Para usar este ejercicio conecta Firebase: ejecuta "flutterfire configure" '
              'en tu proyecto y activa AI Logic en la consola de Firebase. Los pasos están en LEEME.md.'),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Asistente con IA')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _mensajes.length,
              itemBuilder: (context, i) {
                final m = _mensajes[i];
                return Align(
                  alignment: m.esUsuario ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    constraints: const BoxConstraints(maxWidth: 300),
                    decoration: BoxDecoration(
                      color: m.esUsuario ? colores.primary : colores.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(m.texto, style: TextStyle(color: m.esUsuario ? colores.onPrimary : null)),
                  ),
                );
              },
            ),
          ),
          if (_pensando) const LinearProgressIndicator(),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('Las respuestas las genera una IA y pueden contener errores.', style: TextStyle(fontSize: 11)),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _texto,
                    decoration: const InputDecoration(hintText: 'Escribe tu pregunta…', border: OutlineInputBorder()),
                    onSubmitted: (_) => _enviar(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _enviar, icon: const Icon(Icons.send)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
