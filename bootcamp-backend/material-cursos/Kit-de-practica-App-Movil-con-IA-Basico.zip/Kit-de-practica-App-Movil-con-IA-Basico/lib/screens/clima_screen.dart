import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Ejercicio 3: consumir una API pública (Open-Meteo, no necesita clave)
class Clima {
  Clima({required this.temperatura, required this.viento});
  final double temperatura;
  final double viento;

  factory Clima.fromJson(Map<String, dynamic> j) => Clima(
        temperatura: (j['temperature_2m'] as num).toDouble(),
        viento: (j['wind_speed_10m'] as num).toDouble(),
      );
}

Future<Clima> obtenerClima() async {
  final uri = Uri.parse('https://api.open-meteo.com/v1/forecast'
      '?latitude=-12.05&longitude=-77.04&current=temperature_2m,wind_speed_10m&timezone=America%2FLima');
  final respuesta = await http.get(uri).timeout(const Duration(seconds: 10));
  if (respuesta.statusCode != 200) throw Exception('El servidor respondió ${respuesta.statusCode}');
  final datos = jsonDecode(respuesta.body) as Map<String, dynamic>;
  return Clima.fromJson(datos['current'] as Map<String, dynamic>);
}

class ClimaScreen extends StatefulWidget {
  const ClimaScreen({super.key});

  @override
  State<ClimaScreen> createState() => _ClimaScreenState();
}

class _ClimaScreenState extends State<ClimaScreen> {
  late Future<Clima> _clima = obtenerClima();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clima en Lima')),
      body: Center(
        child: FutureBuilder<Clima>(
          future: _clima,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) return const CircularProgressIndicator();
            if (snap.hasError) {
              return Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('No se pudo obtener el clima. Revisa tu conexión.'),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: () => setState(() => _clima = obtenerClima()),
                  child: const Text('Reintentar'),
                ),
              ]);
            }
            final c = snap.data!;
            return Column(mainAxisSize: MainAxisSize.min, children: [
              Text('${c.temperatura.toStringAsFixed(1)} °C', style: Theme.of(context).textTheme.displayMedium),
              Text('Viento: ${c.viento.toStringAsFixed(0)} km/h'),
            ]);
          },
        ),
      ),
    );
  }
}
