import 'package:flutter/material.dart';

import 'asistente_screen.dart';
import 'clima_screen.dart';
import 'tareas_screen.dart';
import 'tarjeta_screen.dart';

class InicioScreen extends StatelessWidget {
  const InicioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ejercicios = <(String, String, IconData, Widget)>[
      ('1 · Tarjeta de presentación', 'Widgets y layouts', Icons.badge_outlined, const TarjetaScreen()),
      ('2 · Lista de tareas', 'Estado y datos guardados', Icons.checklist, const TareasScreen()),
      ('3 · Clima en Lima', 'Consumo de una API', Icons.cloud_outlined, const ClimaScreen()),
      ('4 · Asistente con IA', 'Gemini con Firebase AI Logic', Icons.auto_awesome, const AsistenteScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Kit de práctica SIJB')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: ejercicios.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final (titulo, sub, icono, pantalla) = ejercicios[i];
          return Card(
            child: ListTile(
              leading: Icon(icono),
              title: Text(titulo),
              subtitle: Text(sub),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => pantalla)),
            ),
          );
        },
      ),
    );
  }
}
