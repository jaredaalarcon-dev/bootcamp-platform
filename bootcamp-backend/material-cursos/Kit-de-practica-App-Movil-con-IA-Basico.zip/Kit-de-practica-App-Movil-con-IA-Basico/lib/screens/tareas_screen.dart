import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Ejercicio 2: estado con setState y datos guardados en el celular
class Tarea {
  Tarea(this.texto, {this.hecha = false});
  final String texto;
  bool hecha;

  Map<String, dynamic> toJson() => {'texto': texto, 'hecha': hecha};
  factory Tarea.fromJson(Map<String, dynamic> j) => Tarea(j['texto'] as String, hecha: j['hecha'] as bool);
}

class TareasScreen extends StatefulWidget {
  const TareasScreen({super.key});

  @override
  State<TareasScreen> createState() => _TareasScreenState();
}

class _TareasScreenState extends State<TareasScreen> {
  static const _clave = 'tareas';
  final _texto = TextEditingController();
  List<Tarea> _tareas = [];

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final prefs = await SharedPreferences.getInstance();
    final guardado = prefs.getString(_clave);
    if (guardado == null) return;
    final lista = (jsonDecode(guardado) as List).cast<Map<String, dynamic>>();
    setState(() => _tareas = lista.map(Tarea.fromJson).toList());
  }

  Future<void> _guardar() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_clave, jsonEncode(_tareas.map((t) => t.toJson()).toList()));
  }

  void _agregar() {
    final texto = _texto.text.trim();
    if (texto.isEmpty) return;
    setState(() => _tareas.add(Tarea(texto)));
    _texto.clear();
    _guardar();
  }

  @override
  void dispose() {
    _texto.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis tareas')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _texto,
                    decoration: const InputDecoration(labelText: 'Nueva tarea', border: OutlineInputBorder()),
                    onSubmitted: (_) => _agregar(),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(onPressed: _agregar, child: const Text('Agregar')),
              ],
            ),
          ),
          Expanded(
            child: _tareas.isEmpty
                ? const Center(child: Text('No hay tareas. ¡Agrega la primera!'))
                : ListView.builder(
                    itemCount: _tareas.length,
                    itemBuilder: (context, i) {
                      final t = _tareas[i];
                      return Dismissible(
                        key: ValueKey('$i-${t.texto}'),
                        onDismissed: (_) {
                          setState(() => _tareas.removeAt(i));
                          _guardar();
                        },
                        child: CheckboxListTile(
                          value: t.hecha,
                          title: Text(t.texto,
                              style: TextStyle(decoration: t.hecha ? TextDecoration.lineThrough : null)),
                          onChanged: (v) {
                            setState(() => t.hecha = v ?? false);
                            _guardar();
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
