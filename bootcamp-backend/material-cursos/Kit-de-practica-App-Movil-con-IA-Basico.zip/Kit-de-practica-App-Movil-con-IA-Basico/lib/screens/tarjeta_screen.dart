import 'package:flutter/material.dart';

// Ejercicio 1: cambia los datos por los tuyos
class TarjetaScreen extends StatelessWidget {
  const TarjetaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Tarjeta de presentación')),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 44,
                  backgroundColor: colores.primary,
                  child: Text('AT', style: TextStyle(fontSize: 28, color: colores.onPrimary)),
                ),
                const SizedBox(height: 16),
                Text('Ana Torres', style: Theme.of(context).textTheme.headlineSmall),
                const Text('Desarrolladora de apps móviles'),
                const Divider(height: 32),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Dato(icono: Icons.email_outlined, texto: 'Correo'),
                    _Dato(icono: Icons.phone_outlined, texto: 'Teléfono'),
                    _Dato(icono: Icons.code, texto: 'GitHub'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Dato extends StatelessWidget {
  const _Dato({required this.icono, required this.texto});
  final IconData icono;
  final String texto;

  @override
  Widget build(BuildContext context) {
    return Column(children: [Icon(icono), const SizedBox(height: 4), Text(texto)]);
  }
}
