# Kit de práctica · Apps móviles con IA (Intermedio)

App de ejemplo con **arquitectura por capas**, **Firebase** (login y Firestore), **ML Kit** (IA en el celular)
y **Gemini** con Firebase AI Logic (streaming, imágenes y JSON estructurado).

## Pasos
```bash
flutter create app_ia
cd app_ia
# Copia la carpeta lib/ y el archivo firestore.rules de este kit
flutter pub add provider firebase_core firebase_auth cloud_firestore firebase_ai image_picker google_mlkit_text_recognition
dart pub global activate flutterfire_cli
flutterfire configure          # crea lib/firebase_options.dart
flutter run
```

En la consola de Firebase activa: **Authentication** (correo y contraseña), **Cloud Firestore** y **AI Logic**.
Publica las reglas de `firestore.rules` en Firestore → Reglas.

### Permisos
- **Android**: ML Kit necesita `minSdkVersion 21` o mayor (en `android/app/build.gradle`).
- **iOS**: agrega en `ios/Runner/Info.plist` las claves `NSCameraUsageDescription` y
  `NSPhotoLibraryUsageDescription` con un texto que explique para qué usas la cámara y las fotos.

## Estructura
```
lib/
├─ main.dart                      Inicia Firebase y los providers
├─ models/nota.dart               Modelo de datos
├─ data/auth_repositorio.dart     Login (Firebase Auth)
├─ data/notas_repositorio.dart    Notas (Cloud Firestore)
├─ services/ocr_servicio.dart     Texto de una foto con ML Kit (sin internet)
├─ services/ia_servicio.dart      Gemini: streaming, imágenes y JSON
├─ state/notas_provider.dart      Estado de las notas (Provider)
└─ screens/                       Pantallas (solo interfaz)
```

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
