# Retos extra · Intermedio

1. **Etiquetas de imagen**: agrega `google_mlkit_image_labeling` y muestra qué objetos hay en una foto (sin internet).
2. **Chat con contexto**: crea un chat con Gemini que conozca tus notas (pásalas en la instrucción del sistema).
3. **App Check**: activa Firebase App Check para proteger tu cuota de IA.
4. **Pruebas**: escribe una prueba unitaria para `Recibo.fromJson` con un JSON incompleto.
5. **Publicación**: genera el App Bundle con `flutter build appbundle` y prepara la ficha de Google Play.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
