import 'package:firebase_auth/firebase_auth.dart';

class AuthRepositorio {
  final _auth = FirebaseAuth.instance;

  Stream<User?> get cambios => _auth.authStateChanges();

  Future<void> entrar(String correo, String clave) =>
      _auth.signInWithEmailAndPassword(email: correo.trim(), password: clave);

  Future<void> registrar(String correo, String clave) =>
      _auth.createUserWithEmailAndPassword(email: correo.trim(), password: clave);

  Future<void> salir() => _auth.signOut();

  /// Mensajes de error entendibles para el usuario
  static String mensaje(Object e) {
    if (e is FirebaseAuthException) {
      return switch (e.code) {
        'invalid-email' => 'El correo no es válido.',
        'weak-password' => 'La contraseña es muy débil (mínimo 6 caracteres).',
        'email-already-in-use' => 'Ese correo ya tiene una cuenta.',
        'invalid-credential' || 'wrong-password' || 'user-not-found' => 'Correo o contraseña incorrectos.',
        _ => 'No se pudo iniciar sesión (${e.code}).',
      };
    }
    return 'Ocurrió un error. Revisa tu conexión.';
  }
}
