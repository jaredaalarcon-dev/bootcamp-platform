import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/nota.dart';

class NotasRepositorio {
  final _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> _notas(String uid) =>
      _db.collection('usuarios').doc(uid).collection('notas');

  /// Notas del usuario en tiempo real, de la más nueva a la más antigua
  Stream<List<Nota>> escuchar(String uid) => _notas(uid)
      .orderBy('creada', descending: true)
      .snapshots()
      .map((s) => s.docs.map(Nota.desdeFirestore).toList());

  Future<void> agregar(String uid, String texto, {String origen = 'manual'}) => _notas(uid).add({
        'texto': texto,
        'origen': origen,
        'creada': FieldValue.serverTimestamp(),
      });

  Future<void> eliminar(String uid, String id) => _notas(uid).doc(id).delete();
}
