import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/auth_repositorio.dart';
import 'data/notas_repositorio.dart';
import 'firebase_options.dart'; // lo crea "flutterfire configure"
import 'screens/inicio_screen.dart';
import 'screens/login_screen.dart';
import 'services/ia_servicio.dart';
import 'services/ocr_servicio.dart';
import 'state/notas_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(
    MultiProvider(
      providers: [
        Provider(create: (_) => AuthRepositorio()),
        Provider(create: (_) => NotasRepositorio()),
        Provider(create: (_) => IaServicio()),
        Provider(create: (_) => OcrServicio(), dispose: (_, s) => s.cerrar()),
      ],
      child: const AppIA(),
    ),
  );
}

class AppIA extends StatelessWidget {
  const AppIA({super.key});

  @override
  Widget build(BuildContext context) {
    const cian = Color(0xFF00C0E7);
    return MaterialApp(
      title: 'App IA · SIJB',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: cian, useMaterial3: true),
      darkTheme: ThemeData(colorSchemeSeed: cian, brightness: Brightness.dark, useMaterial3: true),
      // Muestra el login o la app según la sesión
      home: StreamBuilder<User?>(
        stream: context.read<AuthRepositorio>().cambios,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final usuario = snap.data;
          if (usuario == null) return const LoginScreen();
          return ChangeNotifierProvider(
            create: (c) => NotasProvider(c.read<NotasRepositorio>(), usuario.uid),
            child: const InicioScreen(),
          );
        },
      ),
    );
  }
}
