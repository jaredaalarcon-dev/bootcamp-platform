import 'package:cloud_firestore/cloud_firestore.dart';

class Nota {
  Nota({required this.id, required this.texto, required this.creada, this.origen = 'manual'});

  final String id;
  final String texto;
  final DateTime creada;
  final String origen; // manual | escaner | ia

  factory Nota.desdeFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return Nota(
      id: doc.id,
      texto: d['texto'] as String? ?? '',
      creada: (d['creada'] as Timestamp?)?.toDate() ?? DateTime.now(),
      origen: d['origen'] as String? ?? 'manual',
    );
  }
}
