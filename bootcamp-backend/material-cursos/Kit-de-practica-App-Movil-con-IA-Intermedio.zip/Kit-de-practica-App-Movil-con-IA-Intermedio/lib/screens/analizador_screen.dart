import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../services/ia_servicio.dart';
import '../state/notas_provider.dart';

/// Ejercicios: describir una foto con streaming y leer un recibo como JSON
class AnalizadorScreen extends StatefulWidget {
  const AnalizadorScreen({super.key});

  @override
  State<AnalizadorScreen> createState() => _AnalizadorScreenState();
}

class _AnalizadorScreenState extends State<AnalizadorScreen> {
  Uint8List? _foto;
  String _respuesta = '';
  bool _ocupado = false;

  Future<Uint8List?> _elegir() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    return x?.readAsBytes();
  }

  Future<void> _describir() async {
    final bytes = await _elegir();
    if (bytes == null || !mounted) return;
    setState(() { _foto = bytes; _respuesta = ''; _ocupado = true; });
    try {
      await for (final parte in context.read<IaServicio>().describirImagen(bytes)) {
        setState(() => _respuesta += parte); // aparece palabra por palabra
      }
    } catch (_) {
      setState(() => _respuesta = 'La IA no pudo responder ahora. Intenta de nuevo.');
    } finally {
      if (mounted) setState(() => _ocupado = false);
    }
  }

  Future<void> _recibo() async {
    final bytes = await _elegir();
    if (bytes == null || !mounted) return;
    setState(() { _foto = bytes; _respuesta = ''; _ocupado = true; });
    try {
      final r = await context.read<IaServicio>().leerRecibo(bytes);
      final lineas = r.productos.map((p) => '• ${p.$1}: S/ ${p.$2.toStringAsFixed(2)}').join('\n');
      setState(() => _respuesta = '${r.comercio} · ${r.fecha}\n$lineas\nTotal: S/ ${r.total.toStringAsFixed(2)}');
    } catch (_) {
      setState(() => _respuesta = 'No se pudo leer el recibo.');
    } finally {
      if (mounted) setState(() => _ocupado = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Analizar con Gemini')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: FilledButton.icon(
              onPressed: _ocupado ? null : _describir, icon: const Icon(Icons.image_search), label: const Text('Describir foto'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(
              onPressed: _ocupado ? null : _recibo, icon: const Icon(Icons.receipt_long), label: const Text('Leer recibo'))),
          ]),
          const SizedBox(height: 16),
          if (_foto != null)
            ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(_foto!, height: 220, fit: BoxFit.cover)),
          if (_ocupado) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
          const SizedBox(height: 12),
          SelectableText(_respuesta),
          if (_respuesta.isNotEmpty && !_ocupado) ...[
            const SizedBox(height: 8),
            const Text('Generado con IA: revisa los datos antes de usarlos.', style: TextStyle(fontSize: 11)),
            FilledButton.tonal(
              onPressed: () async {
                await context.read<NotasProvider>().agregar(_respuesta, origen: 'ia');
                if (context.mounted) Navigator.pop(context);
              },
              child: const Text('Guardar como nota'),
            ),
          ],
        ],
      ),
    );
  }
}
