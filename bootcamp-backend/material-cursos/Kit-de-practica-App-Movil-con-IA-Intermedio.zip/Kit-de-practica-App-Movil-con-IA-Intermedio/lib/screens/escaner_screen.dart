import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../services/ocr_servicio.dart';
import '../state/notas_provider.dart';

/// Ejercicio: escáner de texto con ML Kit (funciona sin internet)
class EscanerScreen extends StatefulWidget {
  const EscanerScreen({super.key});

  @override
  State<EscanerScreen> createState() => _EscanerScreenState();
}

class _EscanerScreenState extends State<EscanerScreen> {
  String _texto = '';
  bool _procesando = false;

  Future<void> _escanear(ImageSource fuente) async {
    final foto = await ImagePicker().pickImage(source: fuente, maxWidth: 2000);
    if (foto == null || !mounted) return;
    setState(() => _procesando = true);
    try {
      final texto = await context.read<OcrServicio>().leerTexto(foto.path);
      setState(() => _texto = texto.isEmpty ? '(No se encontró texto)' : texto);
    } catch (_) {
      setState(() => _texto = 'No se pudo procesar la imagen.');
    } finally {
      if (mounted) setState(() => _procesando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Escanear texto')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              Expanded(child: FilledButton.icon(
                onPressed: () => _escanear(ImageSource.camera),
                icon: const Icon(Icons.photo_camera), label: const Text('Cámara'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(
                onPressed: () => _escanear(ImageSource.gallery),
                icon: const Icon(Icons.photo_library_outlined), label: const Text('Galería'))),
            ]),
            const SizedBox(height: 16),
            if (_procesando) const LinearProgressIndicator(),
            Expanded(child: SingleChildScrollView(child: SelectableText(_texto))),
            if (_texto.isNotEmpty && !_procesando)
              FilledButton.tonal(
                onPressed: () async {
                  await context.read<NotasProvider>().agregar(_texto, origen: 'escaner');
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('Guardar como nota'),
              ),
          ],
        ),
      ),
    );
  }
}
