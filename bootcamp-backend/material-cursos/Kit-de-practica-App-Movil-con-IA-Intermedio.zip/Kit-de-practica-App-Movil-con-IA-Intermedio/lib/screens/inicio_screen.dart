import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/auth_repositorio.dart';
import '../state/notas_provider.dart';
import 'analizador_screen.dart';
import 'escaner_screen.dart';

class InicioScreen extends StatelessWidget {
  const InicioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final estado = context.watch<NotasProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis notas'),
        actions: [
          IconButton(
            tooltip: 'Escanear texto (ML Kit)',
            icon: const Icon(Icons.document_scanner_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChangeNotifierProvider.value(value: estado, child: const EscanerScreen()),
            )),
          ),
          IconButton(
            tooltip: 'Analizar foto con Gemini',
            icon: const Icon(Icons.auto_awesome),
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChangeNotifierProvider.value(value: estado, child: const AnalizadorScreen()),
            )),
          ),
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthRepositorio>().salir(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _nuevaNota(context),
        child: const Icon(Icons.add),
      ),
      body: estado.cargando
          ? const Center(child: CircularProgressIndicator())
          : estado.error != null
              ? Center(child: Text(estado.error!))
              : estado.notas.isEmpty
                  ? const Center(child: Text('Aún no tienes notas.'))
                  : ListView.builder(
                      itemCount: estado.notas.length,
                      itemBuilder: (context, i) {
                        final n = estado.notas[i];
                        return ListTile(
                          leading: Icon(switch (n.origen) {
                            'escaner' => Icons.document_scanner_outlined,
                            'ia' => Icons.auto_awesome,
                            _ => Icons.notes,
                          }),
                          title: Text(n.texto, maxLines: 3, overflow: TextOverflow.ellipsis),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => estado.eliminar(n.id),
                          ),
                        );
                      },
                    ),
    );
  }

  Future<void> _nuevaNota(BuildContext context) async {
    final ctrl = TextEditingController();
    final texto = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Nueva nota'),
        content: TextField(controller: ctrl, autofocus: true, maxLines: 4),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text.trim()), child: const Text('Guardar')),
        ],
      ),
    );
    if (texto != null && texto.isNotEmpty && context.mounted) {
      await context.read<NotasProvider>().agregar(texto);
    }
  }
}
