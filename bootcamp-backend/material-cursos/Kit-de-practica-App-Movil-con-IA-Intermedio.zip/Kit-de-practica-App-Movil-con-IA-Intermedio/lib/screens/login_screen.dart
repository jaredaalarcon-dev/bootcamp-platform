import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/auth_repositorio.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _correo = TextEditingController();
  final _clave = TextEditingController();
  bool _ocupado = false;
  String? _error;

  Future<void> _accion(bool registrar) async {
    setState(() {
      _ocupado = true;
      _error = null;
    });
    final auth = context.read<AuthRepositorio>();
    try {
      registrar
          ? await auth.registrar(_correo.text, _clave.text)
          : await auth.entrar(_correo.text, _clave.text);
    } catch (e) {
      setState(() => _error = AuthRepositorio.mensaje(e));
    } finally {
      if (mounted) setState(() => _ocupado = false);
    }
  }

  @override
  void dispose() {
    _correo.dispose();
    _clave.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 48),
            Text('App IA · SIJB', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 24),
            TextField(
              controller: _correo,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Correo', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _clave,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Contraseña', border: OutlineInputBorder()),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            const SizedBox(height: 20),
            FilledButton(onPressed: _ocupado ? null : () => _accion(false), child: const Text('Entrar')),
            TextButton(onPressed: _ocupado ? null : () => _accion(true), child: const Text('Crear cuenta')),
          ],
        ),
      ),
    );
  }
}
