import 'dart:convert';
import 'dart:typed_data';

import 'package:firebase_ai/firebase_ai.dart';

/// IA generativa con Gemini a través de Firebase AI Logic (sin claves en la app).
class IaServicio {
  // Usa el modelo vigente que indique la documentación de Firebase AI Logic
  static const _modelo = 'gemini-2.5-flash';

  final _texto = FirebaseAI.googleAI().generativeModel(
    model: _modelo,
    systemInstruction: Content.system('Responde en español, claro y breve.'),
  );

  /// Describe una imagen; la respuesta llega por partes (streaming)
  Stream<String> describirImagen(Uint8List bytes, {String pregunta = 'Describe esta imagen en 3 líneas.'}) async* {
    final contenido = Content.multi([TextPart(pregunta), InlineDataPart('image/jpeg', bytes)]);
    await for (final parte in _texto.generateContentStream([contenido])) {
      final t = parte.text;
      if (t != null && t.isNotEmpty) yield t;
    }
  }

  /// Lee un recibo y devuelve datos estructurados (JSON con esquema)
  Future<Recibo> leerRecibo(Uint8List bytes) async {
    final esquema = Schema.object(properties: {
      'comercio': Schema.string(),
      'fecha': Schema.string(description: 'Fecha en formato AAAA-MM-DD'),
      'total': Schema.number(),
      'productos': Schema.array(
        items: Schema.object(properties: {'nombre': Schema.string(), 'precio': Schema.number()}),
      ),
    });
    final modeloJson = FirebaseAI.googleAI().generativeModel(
      model: _modelo,
      generationConfig: GenerationConfig(responseMimeType: 'application/json', responseSchema: esquema),
    );
    final r = await modeloJson.generateContent([
      Content.multi([
        TextPart('Extrae los datos de este recibo o boleta. Si un dato no se ve, deja texto vacío o 0.'),
        InlineDataPart('image/jpeg', bytes),
      ]),
    ]);
    // Valida siempre lo que devuelve la IA antes de usarlo
    final datos = jsonDecode(r.text ?? '{}') as Map<String, dynamic>;
    return Recibo.fromJson(datos);
  }
}

class Recibo {
  Recibo({required this.comercio, required this.fecha, required this.total, required this.productos});
  final String comercio;
  final String fecha;
  final double total;
  final List<(String, double)> productos;

  factory Recibo.fromJson(Map<String, dynamic> j) => Recibo(
        comercio: j['comercio'] as String? ?? '',
        fecha: j['fecha'] as String? ?? '',
        total: (j['total'] as num?)?.toDouble() ?? 0,
        productos: ((j['productos'] as List?) ?? [])
            .whereType<Map<String, dynamic>>()
            .map((p) => (p['nombre'] as String? ?? '', (p['precio'] as num?)?.toDouble() ?? 0))
            .toList(),
      );
}
