import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// IA en el dispositivo: reconoce texto de una foto SIN internet y sin costo.
class OcrServicio {
  final _reconocedor = TextRecognizer(script: TextRecognitionScript.latin);

  Future<String> leerTexto(String rutaImagen) async {
    final resultado = await _reconocedor.processImage(InputImage.fromFilePath(rutaImagen));
    return resultado.text.trim();
  }

  void cerrar() => _reconocedor.close();
}
