import 'dart:async';

import 'package:flutter/foundation.dart';

import '../data/notas_repositorio.dart';
import '../models/nota.dart';

class NotasProvider extends ChangeNotifier {
  NotasProvider(this._repo, this.uid) {
    _sub = _repo.escuchar(uid).listen(
      (lista) {
        notas = lista;
        cargando = false;
        notifyListeners();
      },
      onError: (_) {
        error = 'No se pudieron cargar tus notas.';
        cargando = false;
        notifyListeners();
      },
    );
  }

  final NotasRepositorio _repo;
  final String uid;
  late final StreamSubscription<List<Nota>> _sub;

  List<Nota> notas = [];
  bool cargando = true;
  String? error;

  Future<void> agregar(String texto, {String origen = 'manual'}) =>
      _repo.agregar(uid, texto, origen: origen);

  Future<void> eliminar(String id) => _repo.eliminar(uid, id);

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
