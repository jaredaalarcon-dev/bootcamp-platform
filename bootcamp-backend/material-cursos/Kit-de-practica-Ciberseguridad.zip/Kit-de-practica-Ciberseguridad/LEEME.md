# Kit de práctica · Ciberseguridad: defensa de aplicaciones web

Material para practicar **defensa** en entornos propios. Incluye ejemplos de código inseguro y su versión
corregida, listas de verificación y plantillas.

> ⚠️ Practica solo en tus propios sistemas o con autorización escrita. Atacar sistemas ajenos es delito
> (Ley N.° 30096, Ley de Delitos Informáticos).

## Contenido
| Archivo | Para qué sirve |
|---|---|
| checklist-owasp-top10.md | Lista de verificación para revisar una aplicación |
| ejemplos/01-consultas-parametrizadas.js | Evitar inyección SQL |
| ejemplos/02-contrasenas-con-bcrypt.js | Guardar y verificar contraseñas |
| ejemplos/03-cabeceras-seguras.js | Helmet, CSP, CORS y límite de intentos |
| ejemplos/04-validacion-de-entradas.js | Validar en el servidor con un esquema |
| ejemplos/.env.example | Cómo separar los secretos del código |
| plantillas/informe-de-seguridad.md | Formato para documentar hallazgos |
| plantillas/plan-de-respuesta-a-incidentes.md | Qué hacer si ocurre un incidente |

Para practicar de forma legal, instala **OWASP Juice Shop** en tu PC:
`docker run --rm -p 3000:3000 bkimminich/juice-shop` y abre http://localhost:3000

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
