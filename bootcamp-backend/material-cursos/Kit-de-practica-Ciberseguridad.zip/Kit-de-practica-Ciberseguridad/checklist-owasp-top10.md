# Lista de verificación · OWASP Top 10 (2021)

Marca cada punto al revisar tu aplicación. Anota la evidencia en el informe.

## A01 · Control de acceso roto
- [ ] Cada endpoint verifica que el usuario tenga permiso sobre **ese** recurso (no solo que esté logueado).
- [ ] Las rutas de administración exigen rol de administrador en el servidor.
- [ ] No se puede ver datos de otro usuario cambiando un id en la URL.

## A02 · Fallas criptográficas
- [ ] Todo el sitio usa HTTPS y HSTS.
- [ ] Contraseñas con bcrypt/Argon2 (nunca MD5/SHA1 ni texto plano).
- [ ] Datos sensibles cifrados en reposo cuando corresponde.

## A03 · Inyección
- [ ] Todas las consultas usan parámetros u ORM.
- [ ] La salida HTML se codifica (sin `innerHTML` con datos del usuario).

## A04 · Diseño inseguro
- [ ] Hay límites de intentos en login, recuperación de contraseña y formularios.
- [ ] Se modelaron amenazas para los flujos críticos (pagos, cuentas).

## A05 · Configuración incorrecta
- [ ] Sin mensajes de error con detalles internos en producción.
- [ ] Cabeceras de seguridad (CSP, X-Content-Type-Options, Referrer-Policy).
- [ ] CORS solo permite los dominios propios.

## A06 · Componentes vulnerables
- [ ] `npm audit` / `composer audit` sin vulnerabilidades altas.
- [ ] Dependencias actualizadas y sin paquetes abandonados.

## A07 · Fallas de identificación y autenticación
- [ ] MFA para administradores.
- [ ] Tokens con expiración y cierre de sesión que los invalida.

## A08 · Integridad de software y datos
- [ ] Las subidas de archivos validan tipo y tamaño, y se guardan fuera de la carpeta pública.

## A09 · Registro y monitoreo
- [ ] Se registran inicios de sesión fallidos y cambios de permisos (sin guardar contraseñas).
- [ ] Hay alertas ante picos de errores o intentos fallidos.

## A10 · SSRF
- [ ] El servidor no descarga URLs arbitrarias que envía el usuario (o usa una lista permitida).
