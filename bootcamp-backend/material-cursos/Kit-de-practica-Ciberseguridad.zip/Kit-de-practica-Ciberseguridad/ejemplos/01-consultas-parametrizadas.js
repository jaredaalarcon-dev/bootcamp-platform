// 01 · Evitar inyección SQL con consultas parametrizadas (Node.js + pg)
import pg from 'pg';
const db = new pg.Pool({ connectionString: process.env.DATABASE_URL });

// ❌ INSEGURO: el texto del usuario se pega dentro de la consulta.
// Si escriben  ' OR '1'='1  la condición siempre es verdadera.
export async function buscarInseguro(correo) {
  return db.query(`SELECT id, nombre FROM usuarios WHERE correo = '${correo}'`);
}

// ✅ SEGURO: el valor viaja aparte ($1) y nunca se interpreta como SQL.
export async function buscarSeguro(correo) {
  return db.query('SELECT id, nombre FROM usuarios WHERE correo = $1', [correo]);
}
