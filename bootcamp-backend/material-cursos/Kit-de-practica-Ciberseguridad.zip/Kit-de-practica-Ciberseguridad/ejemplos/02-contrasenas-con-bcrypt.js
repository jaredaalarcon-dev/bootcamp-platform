// 02 · Guardar contraseñas con bcrypt (npm install bcrypt)
import bcrypt from 'bcrypt';

const COSTO = 12; // más alto = más lento para un atacante (y para ti)

export async function registrar(contrasena) {
  if (contrasena.length < 10) throw new Error('Usa al menos 10 caracteres');
  const hash = await bcrypt.hash(contrasena, COSTO); // incluye la "sal" automáticamente
  return hash; // guarda SOLO el hash en la base de datos
}

export async function verificar(contrasena, hashGuardado) {
  // Compara en tiempo constante: no revela cuántos caracteres coinciden
  return bcrypt.compare(contrasena, hashGuardado);
}

// Mensaje genérico: no digas si falló el correo o la contraseña
export const ERROR_LOGIN = 'Correo o contraseña incorrectos';
