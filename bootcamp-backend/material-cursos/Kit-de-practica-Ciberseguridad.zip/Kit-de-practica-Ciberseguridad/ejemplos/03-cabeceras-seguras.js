// 03 · Cabeceras de seguridad, CORS y límite de intentos (Express)
// npm install express helmet cors express-rate-limit
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],          // sin scripts de otros dominios
      imgSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"],
    },
  },
  hsts: { maxAge: 31536000, includeSubDomains: true },
}));

// Solo tu frontend puede llamar a la API
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));

// Máximo 5 intentos de inicio de sesión cada 15 minutos por IP
app.use('/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: true }));

app.use(express.json({ limit: '100kb' })); // evita cuerpos gigantes

app.listen(3000);
