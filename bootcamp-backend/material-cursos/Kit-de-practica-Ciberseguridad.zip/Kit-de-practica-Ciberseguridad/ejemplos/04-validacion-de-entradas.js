// 04 · Validar SIEMPRE en el servidor (npm install zod)
import { z } from 'zod';

const Registro = z.object({
  nombre: z.string().trim().min(2).max(80),
  correo: z.string().trim().toLowerCase().email(),
  edad: z.coerce.number().int().min(14).max(120),
});

export function validarRegistro(body) {
  const r = Registro.safeParse(body);
  if (!r.success) {
    // Devuelve errores claros, sin detalles internos
    return { ok: false, errores: r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) };
  }
  return { ok: true, datos: r.data }; // usa SOLO los datos validados
}
