# Informe de revisión de seguridad

**Aplicación:**  
**Fecha:**  
**Responsable:**  
**Alcance y autorización:** (qué se revisó y quién lo autorizó)

## Resumen ejecutivo
(3 – 5 líneas para el negocio: principales riesgos y qué se recomienda)

## Hallazgos
| N.° | Hallazgo | Categoría OWASP | Riesgo (Alto/Medio/Bajo) | Estado |
|---|---|---|---|---|
| 1 | | | | |

### Hallazgo 1 · (título)
- **Descripción:**
- **Evidencia:** (captura o petición, sin datos personales reales)
- **Impacto:**
- **Recomendación:**
- **Verificación de la corrección:**

## Conclusiones y próximos pasos
