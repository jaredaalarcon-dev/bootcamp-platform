# Plan básico de respuesta a incidentes

1. **Detectar y reportar** – ¿Quién recibe la alerta? Canal y teléfono de contacto.
2. **Contener** – Aislar el servidor o la cuenta afectada; cambiar credenciales comprometidas.
3. **Erradicar** – Corregir la vulnerabilidad, eliminar accesos no autorizados.
4. **Recuperar** – Restaurar desde copias de seguridad verificadas y monitorear.
5. **Comunicar** – Informar a los afectados y, si hay datos personales, evaluar la comunicación
   a la Autoridad Nacional de Protección de Datos Personales.
6. **Aprender** – Reunión posterior: qué pasó, por qué y qué se cambiará.

| Rol | Nombre | Contacto |
|---|---|---|
| Responsable del incidente | | |
| Técnico | | |
| Comunicaciones | | |
