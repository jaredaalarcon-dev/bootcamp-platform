# Kit de práctica · Desarrollo web con Laravel

Archivos de un CRUD de **Tareas** para copiar en un proyecto Laravel nuevo y completar los ejercicios.

## Pasos
```bash
composer create-project laravel/laravel tareas
cd tareas
# Copia las carpetas de este kit encima del proyecto (app, database, resources, routes)
php artisan migrate
php artisan db:seed --class=TareaSeeder
php artisan serve
```
Abre http://127.0.0.1:8000/tareas

## Contenido
- `app/Models/Tarea.php` – modelo Eloquent con `$fillable` y *casts*.
- `app/Http/Controllers/TareaController.php` – controlador de recursos con validación.
- `app/Http/Requests/TareaRequest.php` – reglas de validación separadas.
- `database/migrations/…_create_tareas_table.php` – tabla `tareas`.
- `database/seeders/TareaSeeder.php` – datos de ejemplo.
- `resources/views/tareas/*.blade.php` – vistas con layout.
- `routes/web.php` – rutas del recurso.
- `ejercicios.md` – retos para practicar.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
