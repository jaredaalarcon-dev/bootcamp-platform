<?php

namespace App\Http\Controllers;

use App\Http\Requests\TareaRequest;
use App\Models\Tarea;

class TareaController extends Controller
{
    public function index()
    {
        $tareas = Tarea::orderBy('completada')->orderBy('vence_el')->paginate(10);
        return view('tareas.index', compact('tareas'));
    }

    public function create()
    {
        return view('tareas.form', ['tarea' => new Tarea()]);
    }

    public function store(TareaRequest $request)
    {
        Tarea::create($request->validated());
        return redirect()->route('tareas.index')->with('ok', 'Tarea creada.');
    }

    public function edit(Tarea $tarea)
    {
        return view('tareas.form', compact('tarea'));
    }

    public function update(TareaRequest $request, Tarea $tarea)
    {
        $tarea->update($request->validated() + ['completada' => $request->boolean('completada')]);
        return redirect()->route('tareas.index')->with('ok', 'Tarea actualizada.');
    }

    public function destroy(Tarea $tarea)
    {
        $tarea->delete();
        return back()->with('ok', 'Tarea eliminada.');
    }
}
