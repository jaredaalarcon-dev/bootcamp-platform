<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TareaRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Ejercicio: solo el dueño de la tarea debería poder editarla
    }

    public function rules(): array
    {
        return [
            'titulo' => ['required', 'string', 'max:120'],
            'descripcion' => ['nullable', 'string', 'max:2000'],
            'prioridad' => ['required', 'in:baja,media,alta'],
            'vence_el' => ['nullable', 'date', 'after_or_equal:today'],
            'completada' => ['sometimes', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'titulo.required' => 'Escribe un título para la tarea.',
            'prioridad.in' => 'La prioridad debe ser baja, media o alta.',
            'vence_el.after_or_equal' => 'La fecha de vencimiento no puede estar en el pasado.',
        ];
    }
}
