<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tarea extends Model
{
    use HasFactory;

    protected $fillable = ['titulo', 'descripcion', 'prioridad', 'completada', 'vence_el'];

    protected $casts = [
        'completada' => 'boolean',
        'vence_el' => 'date',
    ];

    // Tareas que aún no se terminan
    public function scopePendientes($query)
    {
        return $query->where('completada', false);
    }
}
