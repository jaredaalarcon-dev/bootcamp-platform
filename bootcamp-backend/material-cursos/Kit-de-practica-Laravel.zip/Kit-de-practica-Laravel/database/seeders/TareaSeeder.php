<?php

namespace Database\Seeders;

use App\Models\Tarea;
use Illuminate\Database\Seeder;

class TareaSeeder extends Seeder
{
    public function run(): void
    {
        $datos = [
            ['titulo' => 'Instalar Laravel', 'prioridad' => 'alta', 'completada' => true],
            ['titulo' => 'Crear la migración de tareas', 'prioridad' => 'alta', 'completada' => true],
            ['titulo' => 'Validar el formulario', 'prioridad' => 'media', 'completada' => false],
            ['titulo' => 'Agregar autenticación', 'prioridad' => 'media', 'completada' => false],
            ['titulo' => 'Publicar el proyecto', 'prioridad' => 'baja', 'completada' => false],
        ];
        foreach ($datos as $d) {
            Tarea::create($d + ['vence_el' => now()->addDays(rand(1, 20))]);
        }
    }
}
