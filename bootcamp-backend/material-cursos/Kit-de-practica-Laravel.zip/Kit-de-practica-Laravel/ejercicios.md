# Ejercicios · Laravel

1. **Filtro de pendientes**: agrega `?estado=pendientes` al listado usando el *scope* `pendientes()`.
2. **Autenticación**: instala Laravel Breeze y haz que cada usuario vea solo sus tareas (agrega `user_id`).
3. **Política de acceso**: crea `TareaPolicy` para que solo el dueño pueda editar o eliminar.
4. **API REST**: expón `GET/POST /api/tareas` con un `JsonResource` y protégela con Sanctum.
5. **Pruebas**: escribe un *feature test* que verifique que no se puede crear una tarea sin título.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
