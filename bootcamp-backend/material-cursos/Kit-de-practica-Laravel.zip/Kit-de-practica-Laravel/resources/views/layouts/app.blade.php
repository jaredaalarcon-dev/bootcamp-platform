<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('titulo', 'Tareas') · Bootcamp SIJB</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 860px; margin: 2rem auto; padding: 0 1rem; color: #111827; }
        a.btn, button { background: #00C0E7; color: #0d0d0d; border: 0; padding: .5rem 1rem; border-radius: .5rem; text-decoration: none; cursor: pointer; }
        .ok { background: #e6f9fd; border-left: 4px solid #00C0E7; padding: .75rem 1rem; }
        .error { color: #E31E24; font-size: .9rem; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: .6rem; border-bottom: 1px solid #e5e7eb; text-align: left; }
    </style>
</head>
<body>
    @if (session('ok')) <p class="ok">{{ session('ok') }}</p> @endif
    @yield('contenido')
</body>
</html>
