@extends('layouts.app')

@section('contenido')
    <h1>{{ $tarea->exists ? 'Editar tarea' : 'Nueva tarea' }}</h1>

    <form method="POST" action="{{ $tarea->exists ? route('tareas.update', $tarea) : route('tareas.store') }}">
        @csrf
        @if ($tarea->exists) @method('PUT') @endif

        <p><label>Título<br><input name="titulo" value="{{ old('titulo', $tarea->titulo) }}" required></label></p>
        @error('titulo') <p class="error">{{ $message }}</p> @enderror

        <p><label>Descripción<br><textarea name="descripcion">{{ old('descripcion', $tarea->descripcion) }}</textarea></label></p>

        <p><label>Prioridad<br>
            <select name="prioridad">
                @foreach (['baja', 'media', 'alta'] as $p)
                    <option value="{{ $p }}" @selected(old('prioridad', $tarea->prioridad ?? 'media') === $p)>{{ ucfirst($p) }}</option>
                @endforeach
            </select>
        </label></p>

        <p><label>Vence el<br><input type="date" name="vence_el" value="{{ old('vence_el', $tarea->vence_el?->format('Y-m-d')) }}"></label></p>
        @error('vence_el') <p class="error">{{ $message }}</p> @enderror

        @if ($tarea->exists)
            <p><label><input type="checkbox" name="completada" value="1" @checked($tarea->completada)> Completada</label></p>
        @endif

        <button type="submit">Guardar</button>
        <a href="{{ route('tareas.index') }}">Cancelar</a>
    </form>
@endsection
