@extends('layouts.app')

@section('contenido')
    <h1>Mis tareas</h1>
    <a class="btn" href="{{ route('tareas.create') }}">+ Nueva tarea</a>

    <table>
        <thead><tr><th>Tarea</th><th>Prioridad</th><th>Vence</th><th>Estado</th><th></th></tr></thead>
        <tbody>
        @forelse ($tareas as $tarea)
            <tr>
                <td>{{ $tarea->titulo }}</td>
                <td>{{ ucfirst($tarea->prioridad) }}</td>
                <td>{{ $tarea->vence_el?->format('d/m/Y') ?? '—' }}</td>
                <td>{{ $tarea->completada ? 'Hecha' : 'Pendiente' }}</td>
                <td>
                    <a href="{{ route('tareas.edit', $tarea) }}">Editar</a>
                    <form action="{{ route('tareas.destroy', $tarea) }}" method="POST" style="display:inline">
                        @csrf @method('DELETE')
                        <button onclick="return confirm('¿Eliminar?')">Eliminar</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="5">No hay tareas todavía.</td></tr>
        @endforelse
        </tbody>
    </table>
    {{ $tareas->links() }}
@endsection
