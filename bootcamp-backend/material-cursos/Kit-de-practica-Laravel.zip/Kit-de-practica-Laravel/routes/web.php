<?php

use App\Http\Controllers\TareaController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/tareas');
Route::resource('tareas', TareaController::class)->except('show');
