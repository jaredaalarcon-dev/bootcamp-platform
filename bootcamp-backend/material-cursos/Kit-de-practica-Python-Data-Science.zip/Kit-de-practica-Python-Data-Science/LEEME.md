# Kit de práctica · Python para Data Science e IA

Notebooks y datos para los ejercicios de la guía. Puedes abrirlos en **Google Colab** (Archivo → Subir notebook)
o en tu PC con Jupyter:

```bash
pip install pandas numpy matplotlib scikit-learn jupyter
jupyter notebook
```

## Contenido
| Archivo | Tema |
|---|---|
| notebooks/01-python-desde-cero.ipynb | Variables, listas, diccionarios, funciones |
| notebooks/02-limpieza-con-pandas.ipynb | Tipos, duplicados, vacíos y fechas |
| notebooks/03-analisis-y-graficos.ipynb | groupby, tablas dinámicas y Matplotlib |
| notebooks/04-primer-modelo.ipynb | Regresión lineal con scikit-learn |
| datos/ventas.csv | 240 ventas **con errores a propósito** para limpiar |
| datos/viviendas.csv | 300 viviendas sintéticas para el modelo |

> Los datos son **ficticios**, generados para practicar.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
