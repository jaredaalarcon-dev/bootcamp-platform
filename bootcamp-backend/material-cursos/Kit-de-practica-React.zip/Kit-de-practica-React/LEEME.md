# Kit de práctica · React

Proyecto base con Vite + React y los componentes de los ejercicios de la guía.

## Cómo empezar
```bash
npm install
npm run dev
```
Abre la dirección que muestra la terminal (normalmente http://localhost:5173).

## Contenido
- `src/components/Perfil.jsx` – componente con props (ejercicio 1).
- `src/components/Contador.jsx` – estado con límites (ejercicio 2).
- `src/components/ListaTareas.jsx` – lista con estado y localStorage (ejercicio 3).
- `src/components/Buscador.jsx` – consumo de API con carga y error (ejercicio 4).
- `src/hooks/useLocalStorage.js` – hook personalizado reutilizable.

## Retos extra
- Agrega filtros (todas / pendientes / hechas) a la lista de tareas.
- Mueve las tareas a un **Context** para usarlas en otra página con React Router.
- Publica tu proyecto en Vercel: `npm run build` y sube el repositorio.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
