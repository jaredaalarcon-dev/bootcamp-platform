import Perfil from './components/Perfil.jsx';
import Contador from './components/Contador.jsx';
import ListaTareas from './components/ListaTareas.jsx';
import Buscador from './components/Buscador.jsx';

export default function App() {
  return (
    <main className="contenedor">
      <h1>Kit de práctica · React</h1>

      <section>
        <h2>1. Props</h2>
        <div className="fila">
          <Perfil nombre="Ana Torres" rol="Frontend" foto="https://i.pravatar.cc/120?img=47" />
          <Perfil nombre="Luis Ramos" rol="Backend" foto="https://i.pravatar.cc/120?img=12" />
          <Perfil nombre="Rosa Díaz" rol="Diseño UX" />
        </div>
      </section>

      <section>
        <h2>2. Estado</h2>
        <Contador minimo={0} maximo={10} />
      </section>

      <section>
        <h2>3. Lista de tareas</h2>
        <ListaTareas />
      </section>

      <section>
        <h2>4. Consumo de API</h2>
        <Buscador />
      </section>
    </main>
  );
}
