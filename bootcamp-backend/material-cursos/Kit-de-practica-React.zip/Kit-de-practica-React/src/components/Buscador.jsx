import { useEffect, useState } from 'react';

// Ejercicio 4: consumir una API con estados de carga, vacío y error
export default function Buscador() {
  const [consulta, setConsulta] = useState('peru');
  const [resultados, setResultados] = useState([]);
  const [estado, setEstado] = useState('cargando'); // cargando | listo | error

  useEffect(() => {
    if (consulta.trim().length < 2) return;
    const control = new AbortController(); // cancela la petición anterior
    const t = setTimeout(async () => {
      setEstado('cargando');
      try {
        const r = await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(consulta)}`, { signal: control.signal });
        if (r.status === 404) { setResultados([]); setEstado('listo'); return; }
        if (!r.ok) throw new Error(r.statusText);
        setResultados(await r.json());
        setEstado('listo');
      } catch (e) {
        if (e.name !== 'AbortError') setEstado('error');
      }
    }, 400); // espera a que el usuario deje de escribir
    return () => { clearTimeout(t); control.abort(); };
  }, [consulta]);

  return (
    <div>
      <label htmlFor="pais">Buscar país</label>
      <input id="pais" value={consulta} onChange={(e) => setConsulta(e.target.value)} />
      {estado === 'cargando' && <p>Cargando…</p>}
      {estado === 'error' && <p className="error">No se pudo consultar. Revisa tu conexión.</p>}
      {estado === 'listo' && resultados.length === 0 && <p>Sin resultados.</p>}
      <ul>
        {resultados.slice(0, 5).map((p) => (
          <li key={p.cca3}>{p.flag} {p.translations?.spa?.common ?? p.name.common} — capital: {p.capital?.[0] ?? '—'}</li>
        ))}
      </ul>
    </div>
  );
}
