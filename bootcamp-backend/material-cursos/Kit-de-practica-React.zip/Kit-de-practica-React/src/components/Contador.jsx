import { useState } from 'react';

// Ejercicio 2: estado con límites
export default function Contador({ minimo = 0, maximo = 10 }) {
  const [valor, setValor] = useState(minimo);
  return (
    <div className="fila">
      <button onClick={() => setValor((v) => Math.max(minimo, v - 1))} disabled={valor === minimo}>−</button>
      <strong aria-live="polite">{valor}</strong>
      <button onClick={() => setValor((v) => Math.min(maximo, v + 1))} disabled={valor === maximo}>+</button>
    </div>
  );
}
