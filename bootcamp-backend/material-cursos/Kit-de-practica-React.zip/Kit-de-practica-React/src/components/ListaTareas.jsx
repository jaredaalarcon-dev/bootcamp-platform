import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage.js';

// Ejercicio 3: agregar, marcar y eliminar (sin modificar el estado directamente)
export default function ListaTareas() {
  const [tareas, setTareas] = useLocalStorage('tareas', []);
  const [texto, setTexto] = useState('');

  const agregar = (e) => {
    e.preventDefault();
    if (!texto.trim()) return;
    setTareas([...tareas, { id: crypto.randomUUID(), texto: texto.trim(), hecha: false }]);
    setTexto('');
  };
  const alternar = (id) => setTareas(tareas.map((t) => (t.id === id ? { ...t, hecha: !t.hecha } : t)));
  const eliminar = (id) => setTareas(tareas.filter((t) => t.id !== id));

  return (
    <div>
      <form onSubmit={agregar} className="fila">
        <label htmlFor="nueva" className="oculto">Nueva tarea</label>
        <input id="nueva" value={texto} onChange={(e) => setTexto(e.target.value)} placeholder="Escribe una tarea…" />
        <button type="submit">Agregar</button>
      </form>
      {tareas.length === 0 ? (
        <p>No hay tareas. ¡Agrega la primera!</p>
      ) : (
        <ul className="tareas">
          {tareas.map((t) => (
            <li key={t.id}>
              <label>
                <input type="checkbox" checked={t.hecha} onChange={() => alternar(t.id)} />
                <span className={t.hecha ? 'hecha' : ''}>{t.texto}</span>
              </label>
              <button onClick={() => eliminar(t.id)} aria-label={`Eliminar ${t.texto}`}>✕</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
