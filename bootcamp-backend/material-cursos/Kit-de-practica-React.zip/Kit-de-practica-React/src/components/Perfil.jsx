// Ejercicio 1: componente que recibe datos por props
export default function Perfil({ nombre, rol, foto }) {
  return (
    <article className="tarjeta">
      {foto ? <img src={foto} alt={`Foto de ${nombre}`} /> : <div className="avatar">{nombre[0]}</div>}
      <h3>{nombre}</h3>
      <p>{rol}</p>
    </article>
  );
}
