import { useEffect, useState } from 'react';

// Hook personalizado: como useState, pero guarda el valor en el navegador
export function useLocalStorage(clave, inicial) {
  const [valor, setValor] = useState(() => {
    try {
      const guardado = localStorage.getItem(clave);
      return guardado ? JSON.parse(guardado) : inicial;
    } catch {
      return inicial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(clave, JSON.stringify(valor));
    } catch {
      /* almacenamiento lleno o bloqueado */
    }
  }, [clave, valor]);

  return [valor, setValor];
}
