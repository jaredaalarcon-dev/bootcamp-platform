# Kit de práctica · Automatización con n8n

Flujos de ejemplo para importar en n8n y practicar los ejercicios de la guía del curso.

## Cómo importar un flujo
1. Abre n8n (n8n Cloud o `npx n8n` en tu PC → http://localhost:5678).
2. Crea un workflow nuevo → menú **⋯** → **Import from File** → elige un `.json` de la carpeta `workflows/`.
3. Revisa cada nodo: los que usan Google Sheets o Gmail necesitan **tus propias credenciales**.
4. Ejecuta con **Test workflow**. Usa *pin data* para probar sin el disparador real.

## Contenido
| Archivo | Ejercicio |
|---|---|
| workflows/01-formulario-a-hoja.json | Formulario → hoja de cálculo con fecha de registro |
| workflows/02-recordatorio-semanal.json | Cada lunes 8:00 envía las tareas pendientes |
| workflows/03-consumo-api.json | Consulta una API pública, filtra y transforma datos |
| workflows/04-clasificador.json | Deriva solicitudes a ventas, soporte o administración |
| datos/solicitudes.csv | Datos de prueba para el clasificador |

## Buenas prácticas
- Nombra cada nodo por lo que hace y documenta con *sticky notes*.
- Nunca escribas claves dentro de los nodos: usa **Credentials**.
- Configura un **Error Workflow** que te avise si algo falla.

¿Dudas? consultas@solucionesintegralesjb.com · WhatsApp +51 943 014 618
